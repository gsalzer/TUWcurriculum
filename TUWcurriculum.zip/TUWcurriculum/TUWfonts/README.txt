The class option "tudeckblatt" of TUWcurriculum.cls requires specific
fonts that are not part of the public repository. If you are an employee
of TU Wien, download the files
TUHeadlineBold.ttf
TUHeadlineRegular.ttf
TUTextLightItalic.ttf
TUTextLight.ttf
TUTextMediumItalic.ttf
TUTextMedium.ttf
TUTextRegularItalic.ttf
TUTextRegular.ttf
from the TU server and copy them into this folder, or contact
gernot.salzer@tuwien.ac.at
